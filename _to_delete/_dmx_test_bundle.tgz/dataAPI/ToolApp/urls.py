from django.urls import path, re_path as url
from ToolApp import views
from ToolApp import mobile_views
from ToolApp import team_views, team_portal_views, attendance_alert_views
from ToolApp import employee_views
from ToolApp import leave_views
from ToolApp import organization_views
from .views import (
    # Pontaj - editare prin sesiuni (nou)
    attendance_edit_day,
    attendance_session_update,
    attendance_session_delete,   # NEW
    attendance_day_delete,       # NEW

    # Pontaj - listări / monitor
    nfc_scan,
    pontaj_clock,
    attendance_today,
    attendance_day,
    attendance_present,
    attendance_range,
    attendance_day_cost_report,
    attendance_cost_report,
    attendance_absence_report,
    attendance_incomplete_report,
    attendance_report_options,
    attendance_worksites,
    attendance_worksite_report,
    monitor_pontaj_page,
    monitor_pontaj_page_white,
    pontaj_stream,
    leave_upsert, 
    leave_mark_range,
    leave_get, 
    leave_delete,
)

urlpatterns = [
    # --- Legacy (existente) ---
    url(r'^user/$', views.userApi),                         url(r'^user/([0-9]+)$', views.userApi),
    url(r'^tool/$', views.toolApi),                         url(r'^tool/([0-9]+)$', views.toolApi),
    url(r'^history/$', views.historyApi),                   url(r'^history/([0-9]+)$', views.historyApi),
    url(r'^material/$', views.materialApi),                 url(r'^material/([0-9]+)$', views.materialApi),
    url(r'^consumable/$', views.consumableApi),             url(r'^consumable/([0-9]+)$', views.consumableApi),
    url(r'^shed/$', views.shedApi),                         url(r'^shed/([0-9]+)$', views.shedApi),
    url(r'^workfield/$', views.workfieldApi),               url(r'^workfield/([0-9]+)$', views.workfieldApi),
    url(r'^unfunctional/$', views.unfunctionalApi),         url(r'^unfunctional/([0-9]+)$', views.unfunctionalApi),
    url(r'^cofrajmetalic/$', views.cofrajmetalicApi),       url(r'^cofrajmetalic/([0-9]+)$', views.cofrajmetalicApi),
    url(r'^cofrajtipdoka/$', views.cofrajtipdokaApi),       url(r'^cofrajtipdoka/([0-9]+)$', views.cofrajtipdokaApi),
    url(r'^popi/$', views.popiApi),                         url(r'^popi/([0-9]+)$', views.popiApi),
    url(r'^schelausoara/$', views.schelausoaraApi),         url(r'^schelausoara/([0-9]+)$', views.schelausoaraApi),
    url(r'^schelafatada/$', views.schelafatadaApi),         url(r'^schelafatada/([0-9]+)$', views.schelafatadaApi),
    url(r'^schelafatadamodulara/$', views.schelafatadamodularaApi),
    url(r'^schelafatadamodulara/([0-9]+)$', views.schelafatadamodularaApi),
    url(r'^mijloacefixe/$', views.mijloacefixeApi),         url(r'^mijloacefixe/([0-9]+)$', views.mijloacefixeApi),
    url(r'^combustibil/$', views.combustibilApi),           url(r'^combustibil/([0-9]+)$', views.combustibilApi),
    url(r'^istoric_schele/$', views.istoricschelaApi),      url(r'^istoric_schele/([0-9]+)$', views.istoricschelaApi),

    # NFC/Tools helpers (existente)
    path('nfc-tag/', views.nfc_tag_view, name='nfc_tag'),
    path('check-nfc-reader/', views.check_nfc_reader, name='check_nfc_reader'),
    path('rfid/entry/', views.rfid_entry_exit),
    path('tools/issue/', views.issue_tool),
    path('tools/return/', views.return_tool),
    path('tools/status/', views.tools_status),

    # --- Pontaj (existente cu /api/) ---
    path('api/app/version/', views.app_version, name='app_version'),
    path('api/newversion/', views.app_version, name='new_version'),
    path('api/nfc/scan/', nfc_scan, name='nfc_scan'),
    path('api/pontaj/login/', views.pontaj_login, name='pontaj_login'),
    path('api/pontaj/clock/', pontaj_clock, name='pontaj_clock'),
    path('api/mobile/employee-dashboard/', mobile_views.employee_dashboard, name='mobile_employee_dashboard'),
    path('api/mobile/attendance-status/', mobile_views.attendance_status, name='mobile_attendance_status'),
    path('api/mobile/access-context/', mobile_views.access_context, name='mobile_access_context'),
    path('api/mobile/teams/', mobile_views.coordinated_teams, name='mobile_coordinated_teams'),
    path('api/mobile/notifications/', mobile_views.mobile_notifications, name='mobile_notifications'),
    path('api/mobile/notifications/read/', mobile_views.mobile_notifications_read, name='mobile_notifications_read'),
    path('api/mobile/device-token/', mobile_views.mobile_device_token, name='mobile_device_token'),
    path('api/mobile/leave-requests/', mobile_views.leave_request_create, name='mobile_leave_request_create'),
    path('api/mobile/leave-balance/', mobile_views.leave_balance, name='mobile_leave_balance'),
    path('api/mobile/leave-requests/list/', mobile_views.leave_request_list, name='mobile_leave_request_list'),
    path('api/mobile/leave-requests/<int:request_id>/cancel/', mobile_views.leave_request_cancel, name='mobile_leave_request_cancel'),
    path('api/mobile/team-dashboard/', mobile_views.team_dashboard, name='mobile_team_dashboard'),
    path('api/mobile/team-dashboard/teams/', mobile_views.team_dashboard_led_teams, name='mobile_team_dashboard_teams'),
    path('api/mobile/team-dashboard/supervised-teams/', mobile_views.team_dashboard_supervised_teams, name='mobile_team_dashboard_supervised_teams'),
    path('api/mobile/team-dashboard/personnel/', mobile_views.team_dashboard_personnel, name='mobile_team_dashboard_personnel'),
    path('api/mobile/team-dashboard/member-candidates/<int:team_id>/', mobile_views.team_dashboard_member_candidates, name='mobile_team_dashboard_member_candidates'),
    path('api/mobile/team-dashboard/transfer-requests/', mobile_views.team_dashboard_transfer_requests, name='mobile_team_dashboard_transfer_create'),
    path('api/mobile/team-dashboard/transfer-requests/list/', mobile_views.team_dashboard_transfer_request_list, name='mobile_team_dashboard_transfer_list'),
    path('api/mobile/team-dashboard/transfer-requests/mine/', mobile_views.team_dashboard_own_transfer_requests, name='mobile_team_dashboard_own_transfer_list'),
    path('api/mobile/team-dashboard/transfer-requests/<int:request_id>/decision/', mobile_views.team_dashboard_transfer_decision, name='mobile_team_dashboard_transfer_decision'),
    path('api/mobile/team-dashboard/leave-requests/', mobile_views.team_dashboard_leave_requests, name='mobile_team_dashboard_leave_create'),
    path('api/mobile/team-dashboard/leave-requests/list/', mobile_views.team_dashboard_leave_request_list, name='mobile_team_dashboard_leave_list'),
    path('api/mobile/team-dashboard/requests/summary/', mobile_views.team_dashboard_request_summary, name='mobile_team_dashboard_request_summary'),
    path('api/mobile/team-dashboard/requests/leaves/', mobile_views.team_dashboard_leave_approvals, name='mobile_team_dashboard_leave_approvals'),
    path('api/mobile/team-dashboard/requests/transfers/', mobile_views.team_dashboard_transfer_approvals, name='mobile_team_dashboard_transfer_approvals'),
    path('api/mobile/team-dashboard/leave-requests/<int:request_id>/decision/', mobile_views.team_dashboard_leave_decision, name='mobile_team_dashboard_leave_decision'),
    path('api/mobile/team-dashboard/missing-today/', mobile_views.team_dashboard_missing_today, name='mobile_team_dashboard_missing_today'),
    path('api/mobile/team-dashboard/absent-today/', mobile_views.team_dashboard_absent_today, name='mobile_team_dashboard_absent_today'),
    path('api/mobile/team-dashboard/members/<int:employee_id>/absent/', mobile_views.team_dashboard_mark_absent, name='mobile_team_dashboard_mark_absent'),
    path('api/mobile/team-dashboard/notifications/', mobile_views.team_dashboard_notifications, name='mobile_team_dashboard_notifications'),
    path('api/mobile/team-dashboard/notifications/read/', mobile_views.team_dashboard_notifications_read, name='mobile_team_dashboard_notifications_read'),
    path('api/mobile/team-dashboard/worksites/', mobile_views.team_dashboard_worksites, name='mobile_team_dashboard_worksites'),
    path('api/organization/', organization_views.organization_chart, name='organization_chart'),
    path('api/organization/members/<int:member_id>/', organization_views.organization_member_detail, name='organization_member_detail'),
    path('api/pontaj/day/', attendance_day, name='attendance_day'),              # GET day aggregate
    path('api/pontaj/present/', attendance_present, name='attendance_present'),
    path('api/pontaj/range/', attendance_range, name='attendance_range'),
    path('api/pontaj/reports/day-cost/', attendance_day_cost_report, name='attendance_day_cost_report'),
    path('api/pontaj/reports/worksites/', attendance_worksite_report, name='attendance_worksite_report'),
    path('api/pontaj/reports/options/', attendance_report_options, name='attendance_report_options'),
    path('api/pontaj/worksites/', attendance_worksites, name='attendance_worksites'),
    path('api/pontaj/reports/costs/', attendance_cost_report, name='attendance_cost_report'),
    path('api/pontaj/reports/absences/', attendance_absence_report, name='attendance_absence_report'),
    path('api/pontaj/reports/incomplete/', attendance_incomplete_report, name='attendance_incomplete_report'),
    path('api/pontaj/today/', attendance_today, name='attendance_today'),
    path('api/pontaj/stream/', pontaj_stream, name='pontaj_stream'),
    path('api/attendance-alerts/', attendance_alert_views.attendance_alerts, name='attendance_alerts'),

    # Pagina monitor
    path('pontaj/monitor/', monitor_pontaj_page, name='monitor_pontaj'),
    path('pontaj/monitor/white/', monitor_pontaj_page_white, name='monitor_pontaj_white'),

    # Bulk users
    path('api/users/bulk/',  views.users_bulk),
    path('api/users/purge/', views.users_purge),

    # --- Aliasuri noi cu prefix /api/ pentru toate cele de sus (legacy REST) ---
    path('api/user/', views.userApi),
    path('api/user/<int:id>', views.userApi),
    path('api/user/<int:id>/attendance-exempt/', views.attendance_exemption, name='attendance_exemption'),

    path('api/tool/', views.toolApi),
    path('api/tool/<int:id>', views.toolApi),
    path('api/tools/assign-quantity/', views.tool_assign_quantity),
    path('api/tools/return-quantity/', views.tool_return_quantity),

    path('api/history/', views.historyApi),
    path('api/history/<int:id>', views.historyApi),

    path('api/material/', views.materialApi),
    path('api/material/<int:id>', views.materialApi),

    path('api/consumable/', views.consumableApi),
    path('api/consumable/<int:id>', views.consumableApi),

    path('api/shed/', views.shedApi),
    path('api/shed/<int:id>', views.shedApi),

    path('api/workfield/', views.workfieldApi),
    path('api/workfield/<int:id>', views.workfieldApi),

    path('api/unfunctional/', views.unfunctionalApi),
    path('api/unfunctional/<int:id>', views.unfunctionalApi),

    path('api/cofrajmetalic/', views.cofrajmetalicApi),
    path('api/cofrajmetalic/<int:id>', views.cofrajmetalicApi),

    path('api/cofrajtipdoka/', views.cofrajtipdokaApi),
    path('api/cofrajtipdoka/<int:id>', views.cofrajtipdokaApi),

    path('api/popi/', views.popiApi),
    path('api/popi/<int:id>', views.popiApi),

    path('api/schelausoara/', views.schelausoaraApi),
    path('api/schelausoara/<int:id>', views.schelausoaraApi),

    path('api/schelafatada/', views.schelafatadaApi),
    path('api/schelafatada/<int:id>', views.schelafatadaApi),

    path('api/schelafatadamodulara/', views.schelafatadamodularaApi),
    path('api/schelafatadamodulara/<int:id>', views.schelafatadamodularaApi),

    path('api/mijloacefixe/', views.mijloacefixeApi),
    path('api/mijloacefixe/<int:id>', views.mijloacefixeApi),

    path('api/combustibil/', views.combustibilApi),
    path('api/combustibil/<int:id>', views.combustibilApi),

    path('api/istoric_schele/', views.istoricschelaApi),
    path('api/istoric_schele/<int:id>', views.istoricschelaApi),

    path('api/pontaj/force_close_1730/', views.attendance_force_close_1730),

    path('api/pay/day/', views.pay_day, name='pay_day'),
    path('api/pay/month/', views.pay_month, name='pay_month'),
    path('api/users/bulk_update/', views.users_bulk_update),

    path('api/auth/login/', views.auth_login),
    path('api/auth/verify/', views.auth_verify),
    path('api/auth/logout/', views.auth_logout),
    path('api/app-auth/login/', views.app_auth_login),
    path('api/app-auth/verify/', views.app_auth_verify),
    path('api/app-auth/modules/', views.app_auth_modules),
    path('api/app-auth/logout/', views.app_auth_logout),
    path('api/app-admin/login/', views.app_admin_login),
    path('api/app-admin/verify/', views.app_admin_verify),
    path('api/app-admin/users/', views.app_admin_users),
    path('api/app-admin/modules/', views.app_admin_modules),
    path('api/app-admin/modules/<str:module_code>/access/', views.app_admin_module_access),
    path('api/warehouse/storekeepers/', views.warehouse_storekeepers, name='warehouse_storekeepers'),

    # Cazări și documentele din fișa angajatului
    path('api/accommodations/', employee_views.accommodations, name='accommodations'),
    path('api/accommodations/assign/', employee_views.accommodation_assignment, name='accommodation_assignment'),
    path('api/employee-document-types/', employee_views.employee_document_types, name='employee_document_types'),
    path('api/employees/<int:employee_id>/documents/', employee_views.employee_documents, name='employee_documents'),
    path('api/employee-documents/<int:document_id>/', employee_views.employee_document_detail, name='employee_document_detail'),
    path('api/employee-documents/<int:document_id>/download/', employee_views.employee_document_download, name='employee_document_download'),

    # Echipe permanente, împrumuturi temporare și situația zilnică
    path('api/teams/', team_views.teams_collection, name='teams_collection'),
    path('api/teams/today/', team_views.teams_today, name='teams_today'),
    path('api/teams/available/', team_views.available_personnel, name='available_personnel'),
    path('api/teams/requests/', team_views.temporary_requests, name='temporary_worker_requests'),
    path('api/teams/requests/<int:request_id>/action/', team_views.temporary_request_action, name='temporary_worker_request_action'),
    path('api/teams/notifications/', team_views.team_notifications, name='team_notifications'),
    path('api/teams/notifications/summary/', team_views.notifications_summary, name='team_notifications_summary'),
    path('api/teams/worksites/', team_views.team_worksites, name='team_worksites'),
    path('api/teams/<int:team_id>/', team_views.team_detail, name='team_detail'),
    path('api/teams/<int:team_id>/members/', team_views.team_members, name='team_members'),
    path('api/team-portal/dashboard/', team_portal_views.portal_dashboard, name='team_portal_dashboard'),
    path('api/team-portal/salary/', team_portal_views.portal_salary, name='team_portal_salary'),
    path('api/team-portal/teams/', team_portal_views.portal_teams, name='team_portal_teams'),
    path('api/team-portal/supervised-teams/', team_portal_views.portal_supervised_teams, name='team_portal_supervised_teams'),
    path('api/team-portal/personnel/', team_portal_views.portal_personnel, name='team_portal_personnel'),
    path('api/team-portal/member-candidates/', team_portal_views.portal_member_candidates, name='team_portal_member_candidates'),
    path('api/team-portal/transfer-requests/', team_portal_views.portal_transfer_requests, name='team_portal_transfer_requests'),
    path('api/team-portal/transfer-requests/mine/', team_portal_views.portal_own_transfer_requests, name='team_portal_own_transfer_requests'),
    path('api/team-portal/transfer-requests/<int:request_id>/decision/', team_portal_views.portal_transfer_decision, name='team_portal_transfer_decision'),
    path('api/team-portal/leave-requests/', team_portal_views.portal_own_leave_requests, name='team_portal_own_leave_requests'),
    path('api/team-portal/leave-requests/<int:request_id>/cancel/', team_portal_views.portal_own_leave_cancel, name='team_portal_own_leave_cancel'),
    path('api/team-portal/requests/', team_portal_views.portal_supervisor_requests, name='team_portal_supervisor_requests'),
    path('api/team-portal/requests/summary/', team_portal_views.portal_supervisor_request_summary, name='team_portal_supervisor_request_summary'),
    path('api/team-portal/requests/leaves/', team_portal_views.portal_supervisor_leave_requests, name='team_portal_supervisor_leave_requests'),
    path('api/team-portal/requests/transfers/', team_portal_views.portal_supervisor_transfer_requests, name='team_portal_supervisor_transfer_requests'),
    path('api/team-portal/leave-requests/<int:request_id>/decision/', team_portal_views.portal_leave_decision, name='team_portal_leave_decision'),
    path('api/team-portal/teams/members/<int:employee_id>/absent/', team_portal_views.portal_mark_absent, name='team_portal_mark_absent'),
    path('api/team-portal/notifications/', team_portal_views.portal_notifications, name='team_portal_notifications'),
    path('api/team-portal/notifications/summary/', team_portal_views.portal_notification_summary, name='team_portal_notification_summary'),
    path('api/team-portal/missing-today/', team_portal_views.portal_missing_today, name='team_portal_missing_today'),
    path('api/team-portal/absent-today/', team_portal_views.portal_absent_today, name='team_portal_absent_today'),
    path('api/team-portal/worksites/', team_portal_views.portal_worksites, name='team_portal_worksites'),
    path('api/team-portal/attendance/', team_portal_views.portal_attendance, name='team_portal_attendance'),
    path('api/organization/departments/<int:department_id>/team/', organization_views.organization_department_team, name='organization_department_team'),

    # Cereri de concediu primite de șefii de echipă și administratori
    path('api/leave-requests/', leave_views.leave_requests_collection, name='leave_requests_collection'),
    path('api/leave-requests/<int:request_id>/decision/', leave_views.leave_request_decision, name='leave_request_decision'),

    # --- PONTAJ: editare manuală pe sesiuni (nou) ---
    path('api/pontaj/day/edit/', attendance_edit_day, name='attendance_edit_day'),                 # POST (replace cu sesiuni)
    path('api/pontaj/session/update/', attendance_session_update, name='attendance_session_update'),  # POST (patch punctual)
    path('api/pontaj/session/delete/', attendance_session_delete, name='attendance_session_delete'),  # POST (delete by id)
    path('api/pontaj/day/delete/', attendance_day_delete, name='attendance_day_delete'),             # DELETE (golește ziua)
    path('api/leave/upsert/', leave_upsert),
    path('api/leave/mark-range/', leave_mark_range, name='leave_mark_range'),
    path('api/leave/get/', leave_get),
    path('api/leave/delete/', leave_delete),
    
    path('api/pontaj/excel/', views.generate_excel, name='pontaj_excel'),
]
